/**
 * Request ID middleware.
 *
 * Adds:
 * - req.requestId
 * - X-Request-Id response header
 */
import crypto from "node:crypto";

export function requestId() {
  return (req, res, next) => {
    const id = crypto.randomUUID();
    req.requestId = id;
    res.setHeader("X-Request-Id", id);
    next();
  };
}
