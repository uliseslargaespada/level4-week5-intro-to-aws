/**
 * Global error handler middleware.
 *
 * Maps common errors to our standard error envelope.
 * Also maps common Postgres error codes:
 * - 23505 unique_violation -> 409
 * - 23503 foreign_key_violation -> 409
 */
import { respondError } from "../utils/respond.js";

/**
 * @param {any} err
 * @returns {{ status: number, code: string, message: string, details?: any } | null}
 */
function mapPgError(err) {
  if (!err || typeof err !== "object") return null;

  // node-postgres error codes: https://www.postgresql.org/docs/current/errcodes-appendix.html
  if (err.code === "23505") {
    return {
      status: 409,
      code: "UNIQUE_CONSTRAINT",
      message: "A record with those unique fields already exists.",
      details: { constraint: err.constraint },
    };
  }

  if (err.code === "23503") {
    return {
      status: 409,
      code: "FOREIGN_KEY_CONSTRAINT",
      message: "A related record was not found (foreign key constraint).",
      details: { constraint: err.constraint },
    };
  }

  return null;
}

export function createErrorHandler() {
  // eslint-disable-next-line no-unused-vars
  return function errorHandler(err, req, res, next) {
    const requestId = req.requestId ?? null;

    const mappedPg = mapPgError(err);
    if (mappedPg) {
      return respondError(
        res,
        mappedPg.status,
        mappedPg.code,
        mappedPg.message,
        mappedPg.details ?? null,
        requestId
      );
    }

    if (err && err.status && err.code) {
      return respondError(res, err.status, err.code, err.message, err.details ?? null, requestId);
    }

    // Unexpected error
    console.error(err);

    return respondError(res, 500, "INTERNAL_SERVER_ERROR", "Something went wrong.", null, requestId);
  };
}
