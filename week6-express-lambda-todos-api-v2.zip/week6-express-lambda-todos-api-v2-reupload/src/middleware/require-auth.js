/**
 * JWT authentication middleware.
 *
 * Reads:
 * - Authorization: Bearer <token>
 *
 * Attaches:
 * - req.user = { id }
 */
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";

export function requireAuth() {
  return (req, _res, next) => {
    const header = req.headers.authorization || "";
    const [type, token] = header.split(" ");

    if (type !== "Bearer" || !token) {
      return next({ status: 401, code: "AUTH_REQUIRED", message: "Missing Bearer token." });
    }

    try {
      const payload = jwt.verify(token, env.JWT_SECRET);
      req.user = { id: payload.sub };
      return next();
    } catch (_err) {
      return next({ status: 401, code: "AUTH_INVALID", message: "Invalid or expired token." });
    }
  };
}
