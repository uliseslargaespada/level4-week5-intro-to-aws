/**
 * AWS Lambda entry point for Express.
 *
 * We wrap the Express app using serverless-express so API Gateway (HTTP API) can invoke it.
 *
 * Note: The serverless-express examples for API Gateway v2 show importing your app and exporting a handler. citeturn0search3
 */
import serverlessExpress from "@codegenie/serverless-express";
import { createRepos } from "./storage/index.js";
import { createApp } from "./app.js";

// Initialize once (improves warm-start performance)
const repos = createRepos();
const app = createApp({ repos });

export const handler = serverlessExpress({ app });
