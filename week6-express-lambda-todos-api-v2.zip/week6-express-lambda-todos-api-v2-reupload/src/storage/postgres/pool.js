/**
 * Postgres connection pool.
 *
 * IMPORTANT for serverless:
 * - Create the pool outside request handlers to reuse connections on warm starts.
 * - Keep max small for classroom usage.
 */
import pg from "pg";

const { Pool } = pg;

export function createPool(connectionString) {
  return new Pool({
    connectionString,
    max: 5,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });
}
