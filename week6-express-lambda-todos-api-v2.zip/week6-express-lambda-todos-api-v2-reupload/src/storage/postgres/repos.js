/**
 * Postgres repositories (Day 4/5).
 */
import { createPool } from "./pool.js";

export function createPostgresRepos(connectionString) {
  const pool = createPool(connectionString);

  return {
    users: {
      async findByEmail({ email }) {
        const { rows } = await pool.query(
          'SELECT id, email, name, password_hash AS "passwordHash", created_at AS "createdAt" FROM users WHERE email = $1 LIMIT 1',
          [email]
        );
        return rows[0] ?? null;
      },

      async findById({ id }) {
        const { rows } = await pool.query(
          'SELECT id, email, name, password_hash AS "passwordHash", created_at AS "createdAt" FROM users WHERE id = $1 LIMIT 1',
          [id]
        );
        return rows[0] ?? null;
      },

      async create({ email, name, passwordHash }) {
        const { rows } = await pool.query(
          'INSERT INTO users (email, name, password_hash) VALUES ($1, $2, $3) RETURNING id, email, name, password_hash AS "passwordHash", created_at AS "createdAt"',
          [email, name, passwordHash]
        );
        return rows[0];
      },
    },

    todos: {
      async list({ userId }) {
        const { rows } = await pool.query(
          'SELECT id, user_id AS "userId", title, completed, created_at AS "createdAt", updated_at AS "updatedAt" FROM todos WHERE user_id = $1 ORDER BY created_at DESC',
          [userId]
        );
        return rows;
      },

      async create({ userId, title }) {
        const { rows } = await pool.query(
          'INSERT INTO todos (user_id, title) VALUES ($1, $2) RETURNING id, user_id AS "userId", title, completed, created_at AS "createdAt", updated_at AS "updatedAt"',
          [userId, title]
        );
        return rows[0];
      },

      async update({ userId, id, title, completed }) {
        const { rows } = await pool.query(
          'UPDATE todos SET title = COALESCE($3, title), completed = COALESCE($4, completed), updated_at = NOW() WHERE id = $1 AND user_id = $2 RETURNING id, user_id AS "userId", title, completed, created_at AS "createdAt", updated_at AS "updatedAt"',
          [id, userId, title ?? null, completed ?? null]
        );
        return rows[0] ?? null;
      },

      async remove({ userId, id }) {
        const { rowCount } = await pool.query("DELETE FROM todos WHERE id = $1 AND user_id = $2", [id, userId]);
        return rowCount > 0;
      },
    },
  };
}
