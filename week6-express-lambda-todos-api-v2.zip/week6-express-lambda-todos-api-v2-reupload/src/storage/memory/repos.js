/**
 * In-memory repositories (Day 3).
 *
 * WARNING: This is for learning only. In Lambda, memory can reset at any time.
 */
import crypto from "node:crypto";

const usersByEmail = new Map(); // email -> user
const usersById = new Map(); // id -> user
const todosByUserId = new Map(); // userId -> Todo[]

function nowIso() {
  return new Date().toISOString();
}

function uuid() {
  return crypto.randomUUID();
}

export function createInMemoryRepos() {
  return {
    users: {
      async findByEmail({ email }) {
        return usersByEmail.get(email) ?? null;
      },

      async findById({ id }) {
        return usersById.get(id) ?? null;
      },

      async create({ email, name, passwordHash }) {
        const id = uuid();
        const user = { id, email, name, passwordHash, createdAt: nowIso() };
        usersByEmail.set(email, user);
        usersById.set(id, user);
        return user;
      },
    },

    todos: {
      async list({ userId }) {
        return todosByUserId.get(userId) ?? [];
      },

      async create({ userId, title }) {
        const todo = { id: uuid(), userId, title, completed: false, createdAt: nowIso() };
        const list = todosByUserId.get(userId) ?? [];
        todosByUserId.set(userId, [todo, ...list]);
        return todo;
      },

      async update({ userId, id, title, completed }) {
        const list = todosByUserId.get(userId) ?? [];
        const idx = list.findIndex((t) => t.id === id);
        if (idx == -1) return null;

        const current = list[idx];
        const next = {
          ...current,
          title: title !== undefined ? title : current.title,
          completed: completed !== undefined ? completed : current.completed,
          updatedAt: nowIso(),
        };

        const updated = [...list];
        updated[idx] = next;
        todosByUserId.set(userId, updated);
        return next;
      },

      async remove({ userId, id }) {
        const list = todosByUserId.get(userId) ?? [];
        const next = list.filter((t) => t.id !== id);
        if (next.length === list.length) return false;
        todosByUserId.set(userId, next);
        return true;
      },
    },
  };
}
