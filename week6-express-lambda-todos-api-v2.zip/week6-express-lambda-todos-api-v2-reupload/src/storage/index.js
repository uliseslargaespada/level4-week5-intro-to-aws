/**
 * Storage abstraction.
 *
 * Day 3: In-memory mode (DATABASE_URL not set).
 * Day 4/5: Postgres mode (DATABASE_URL set).
 */
import { env } from "../config/env.js";
import { createInMemoryRepos } from "./memory/repos.js";
import { createPostgresRepos } from "./postgres/repos.js";

export function createRepos() {
  if (env.DATABASE_URL && env.DATABASE_URL.trim().length > 0) {
    return createPostgresRepos(env.DATABASE_URL);
  }

  return createInMemoryRepos();
}
