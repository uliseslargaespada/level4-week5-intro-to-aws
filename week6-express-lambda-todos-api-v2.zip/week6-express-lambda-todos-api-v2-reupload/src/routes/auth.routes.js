/**
 * Auth routes:
 * - POST /auth/register
 * - POST /auth/login
 */
import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { env } from "../config/env.js";
import { respondOk } from "../utils/respond.js";
import { asyncHandler } from "../utils/async-handler.js";

export function createAuthRouter({ repos }) {
  const router = Router();

  router.post(
    "/register",
    asyncHandler(async (req, res) => {
      const { email, name, password } = req.body ?? {};

      if (typeof email !== "string" || !email.includes("@")) {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "Invalid email." } });
      }
      if (typeof name !== "string" || name.trim().length < 2) {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "Invalid name." } });
      }
      if (typeof password !== "string" || password.length < 8) {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "Password must be at least 8 characters." } });
      }

      const normalizedEmail = email.trim().toLowerCase();

      const existing = await repos.users.findByEmail({ email: normalizedEmail });
      if (existing) {
        return res.status(409).json({ ok: false, error: { code: "EMAIL_TAKEN", message: "Email already registered." } });
      }

      const passwordHash = await bcrypt.hash(password, 10);
      const user = await repos.users.create({
        email: normalizedEmail,
        name: name.trim(),
        passwordHash,
      });

      return respondOk(res, { id: user.id, email: user.email, name: user.name }, {}, 201);
    })
  );

  router.post(
    "/login",
    asyncHandler(async (req, res) => {
      const { email, password } = req.body ?? {};

      if (typeof email !== "string" || typeof password !== "string") {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "Email and password are required." } });
      }

      const user = await repos.users.findByEmail({ email: email.trim().toLowerCase() });
      if (!user) {
        return res.status(401).json({ ok: false, error: { code: "INVALID_CREDENTIALS", message: "Invalid credentials." } });
      }

      const ok = await bcrypt.compare(password, user.passwordHash);
      if (!ok) {
        return res.status(401).json({ ok: false, error: { code: "INVALID_CREDENTIALS", message: "Invalid credentials." } });
      }

      const token = jwt.sign({ sub: user.id }, env.JWT_SECRET, { expiresIn: "2h" });

      return respondOk(res, { token }, {}, 200);
    })
  );

  return router;
}
