/**
 * Todos routes (protected):
 * - GET    /todos
 * - POST   /todos
 * - PATCH  /todos/:id
 * - DELETE /todos/:id
 */
import { Router } from "express";
import { respondOk } from "../utils/respond.js";
import { asyncHandler } from "../utils/async-handler.js";
import { requireAuth } from "../middleware/require-auth.js";

export function createTodosRouter({ repos }) {
  const router = Router();

  router.use(requireAuth());

  router.get(
    "/",
    asyncHandler(async (req, res) => {
      const todos = await repos.todos.list({ userId: req.user.id });
      return respondOk(res, todos, { total: todos.length });
    })
  );

  router.post(
    "/",
    asyncHandler(async (req, res) => {
      const { title } = req.body ?? {};

      if (typeof title !== "string" || title.trim().length === 0) {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "Title is required." } });
      }

      const todo = await repos.todos.create({ userId: req.user.id, title: title.trim() });
      return respondOk(res, todo, {}, 201);
    })
  );

  router.patch(
    "/:id",
    asyncHandler(async (req, res) => {
      const { id } = req.params;
      const { title, completed } = req.body ?? {};

      if (title !== undefined && (typeof title !== "string" || title.trim().length === 0)) {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "If provided, title must be a non-empty string." } });
      }
      if (completed !== undefined && typeof completed !== "boolean") {
        return res.status(400).json({ ok: false, error: { code: "VALIDATION_ERROR", message: "If provided, completed must be a boolean." } });
      }

      const updated = await repos.todos.update({
        userId: req.user.id,
        id,
        title: title !== undefined ? title.trim() : undefined,
        completed,
      });

      if (!updated) {
        return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Todo not found." } });
      }

      return respondOk(res, updated, {});
    })
  );

  router.delete(
    "/:id",
    asyncHandler(async (req, res) => {
      const { id } = req.params;

      const ok = await repos.todos.remove({ userId: req.user.id, id });
      if (!ok) {
        return res.status(404).json({ ok: false, error: { code: "NOT_FOUND", message: "Todo not found." } });
      }

      return respondOk(res, { deleted: true }, {});
    })
  );

  return router;
}
