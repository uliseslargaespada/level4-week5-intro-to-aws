/**
 * Environment configuration.
 *
 * Keep config reads centralized so it is easier to audit and validate.
 */
import "dotenv/config";

/**
 * Parse a comma-separated env var into an array of trimmed strings.
 *
 * @param {string | undefined} value
 * @returns {string[]}
 */
function parseCsv(value) {
  if (!value) return [];
  return value
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean);
}

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  PORT: Number(process.env.PORT ?? 3000),

  JWT_SECRET: process.env.JWT_SECRET ?? "dev-secret-change-me",

  DATABASE_URL: process.env.DATABASE_URL || "",

  CORS_ORIGINS: parseCsv(process.env.CORS_ORIGINS),
};
