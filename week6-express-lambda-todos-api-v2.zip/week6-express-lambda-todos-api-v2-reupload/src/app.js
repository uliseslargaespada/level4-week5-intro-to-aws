/**
 * Express application factory.
 *
 * This file contains ONLY app wiring, so it can run:
 * - locally (src/server.js)
 * - in AWS Lambda (src/lambda.js via serverless-express)
 */
import express from "express";
import cors from "cors";

import { env } from "./config/env.js";
import { requestId } from "./middleware/request-id.js";
import { createErrorHandler } from "./middleware/error-handler.js";
import { createAuthRouter } from "./routes/auth.routes.js";
import { createTodosRouter } from "./routes/todos.routes.js";

export function createApp({ repos }) {
  const app = express();

  app.use(requestId());

  // CORS:
  // - For local dev, allow localhost.
  // - For deployments, use env (and/or API Gateway CORS).
  app.use(
    cors({
      origin: env.CORS_ORIGINS.length ? env.CORS_ORIGINS : true,
      credentials: false,
    })
  );

  app.use(express.json({ limit: "1mb" }));

  app.get("/health", (_req, res) => res.json({ ok: true, data: { status: "ok" }, meta: {} }));

  app.use("/auth", createAuthRouter({ repos }));
  app.use("/todos", createTodosRouter({ repos }));

  app.use(createErrorHandler());

  return app;
}
