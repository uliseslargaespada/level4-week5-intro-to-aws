/**
 * Local server entry point.
 */
import { env } from "./config/env.js";
import { createRepos } from "./storage/index.js";
import { createApp } from "./app.js";

const repos = createRepos();
const app = createApp({ repos });

app.listen(env.PORT, () => {
  console.log(`✅ API listening on http://localhost:${env.PORT}`);
  console.log(env.DATABASE_URL ? "Mode: Postgres" : "Mode: In-memory");
});
