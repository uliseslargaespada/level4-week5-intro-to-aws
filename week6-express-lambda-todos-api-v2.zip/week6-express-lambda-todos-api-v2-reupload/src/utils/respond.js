/**
 * Standard API response helpers.
 *
 * We keep envelopes consistent so the frontend can handle responses predictably.
 */

/**
 * Send a success response.
 *
 * @param {import("express").Response} res
 * @param {any} data
 * @param {Record<string, any>} meta
 * @param {number} status
 */
export function respondOk(res, data, meta = {}, status = 200) {
  return res.status(status).json({ ok: true, data, meta });
}

/**
 * Send an error response.
 *
 * @param {import("express").Response} res
 * @param {number} status
 * @param {string} code
 * @param {string} message
 * @param {any} details
 * @param {string|null} requestId
 */
export function respondError(res, status, code, message, details = null, requestId = null) {
  return res.status(status).json({
    ok: false,
    error: { code, message, details, requestId },
  });
}
