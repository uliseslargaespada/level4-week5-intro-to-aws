/**
 * Async handler wrapper.
 *
 * Express does not automatically catch async errors.
 * This helper forwards exceptions to the global error handler.
 *
 * @param {(req: any, res: any, next: any) => Promise<any>} fn
 */
export function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}
