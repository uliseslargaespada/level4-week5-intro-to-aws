/**
 * Apply schema.sql to the configured DATABASE_URL.
 *
 * This is a simple script for the course to avoid introducing migration tooling in Week 6.
 * For production projects, use migrations.
 */
import fs from "node:fs";
import path from "node:path";
import pg from "pg";
import { env } from "../config/env.js";

const { Client } = pg;

if (!env.DATABASE_URL) {
  console.error("DATABASE_URL is required to apply schema.");
  process.exit(1);
}

const schemaPath = path.resolve(process.cwd(), "src/db/schema.sql");
const sql = fs.readFileSync(schemaPath, "utf-8");

const client = new Client({ connectionString: env.DATABASE_URL });

try {
  await client.connect();
  await client.query(sql);
  console.log("✅ Schema applied successfully.");
} catch (err) {
  console.error("❌ Failed to apply schema:", err);
  process.exit(1);
} finally {
  await client.end();
}
