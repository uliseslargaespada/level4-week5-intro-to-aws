# Week 6 — Express on AWS Lambda + API Gateway (HTTP API)
## Todos API (Auth + Todos CRUD)

This project supports **two modes**:
1) **In-memory mode** (no DATABASE_URL) — used for Day 3 deployment practice
2) **Postgres mode** (DATABASE_URL set) — used for Day 4 (local Postgres) and Day 5 (RDS)

## Routes
- GET  /health
- POST /auth/register
- POST /auth/login
- GET  /todos              (auth)
- POST /todos              (auth)
- PATCH /todos/:id          (auth)
- DELETE /todos/:id         (auth)

## Local development
```bash
cp .env.example .env
npm install
npm run dev
```

## Postgres schema (Day 4+)
1) Create a DB named `todos_api`
2) Set `DATABASE_URL` in `.env`
3) Apply schema:
```bash
npm run db:schema
```

## Deploy to Lambda (Day 3)
- Zip the project **including `node_modules`** and upload to AWS Lambda.
- Set handler to: `src/lambda.handler`
- Use API Gateway HTTP API with a `$default` route to forward all paths to this Lambda.
